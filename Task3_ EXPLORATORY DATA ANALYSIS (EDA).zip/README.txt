# AI Career Guidance India — Task 3 EDA

## Files
- `career_guidance_dataset.csv` — exact 10-row, 5-column sample from Task 2
- `Task3_EDA_AI_Career_Guidance_India.ipynb` — runnable Jupyter Notebook
- `task3_eda.py` — standalone Python script
- `Task3_EDA_Report.pdf` — EDA report
- `graphs/` — career distribution, average scores, correlation matrix

## Run
Install dependencies: `pip install pandas matplotlib jupyter`
Keep the CSV in the same folder as the notebook, then open the notebook and run all cells.

## Important limitation
This is the same tiny 10-row learning sample used in Task 2. Results are illustrative only; they are not statistically reliable and are not representative of students in India.
