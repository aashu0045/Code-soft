import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("career_guidance_dataset.csv")
print("Shape:", df.shape)
print("\\nInfo:")
df.info()
print("\\nMissing values:")
print(df.isnull().sum())
print("\\nDuplicates:", df.duplicated().sum())
print("\\nDescriptive statistics:")
print(df.describe())
print("\\nCareer counts:")
print(df["Career"].value_counts())

features = ["Python_Skill", "SQL_Skill", "AI_Interest", "Problem_Solving"]
df["Career"].value_counts().plot(kind="bar", title="Career Category Distribution")
plt.tight_layout()
plt.show()

df[features].mean().plot(kind="bar", title="Average Skill and Interest Scores")
plt.ylabel("Average score (1–5)")
plt.tight_layout()
plt.show()

corr = df[features].corr()
print("\\nCorrelation matrix:")
print(corr.round(2))
corr.to_csv("correlation_matrix.csv")
