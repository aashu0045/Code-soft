"""
Task 2: Predictive Modeling Using Machine Learning
Dataset: scikit-learn Wine Recognition dataset (public educational dataset)
Install: pip install pandas numpy matplotlib scikit-learn
Run: python task2_predictive_modeling.py
"""
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay
from pathlib import Path

OUT = Path("output")
OUT.mkdir(exist_ok=True)

# Load a standard educational dataset
wine = load_wine(as_frame=True)
df = wine.frame.copy()
X = df.drop(columns=["target"])
y = df["target"]

# Split into training and testing data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

# Train model
model = RandomForestClassifier(n_estimators=200, random_state=42)
model.fit(X_train, y_train)

# Predict and evaluate
y_pred = model.predict(X_test)
print("Accuracy:", round(accuracy_score(y_test, y_pred), 4))
print("\\nClassification report:\\n",
      classification_report(y_test, y_pred, target_names=wine.target_names))

# Confusion matrix visualization
ConfusionMatrixDisplay.from_predictions(
    y_test, y_pred, display_labels=wine.target_names, cmap="Blues"
)
plt.title("Confusion Matrix - Wine Classification")
plt.tight_layout()
plt.savefig(OUT / "confusion_matrix.png")
plt.show()

# Feature importance
importances = pd.Series(model.feature_importances_, index=X.columns).sort_values()
importances.plot(kind="barh", figsize=(8, 6))
plt.title("Random Forest Feature Importance")
plt.xlabel("Importance")
plt.tight_layout()
plt.savefig(OUT / "feature_importance.png")
plt.show()

# Save predictions and model
results = X_test.copy()
results["Actual_Class"] = y_test
results["Predicted_Class"] = y_pred
results.to_csv(OUT / "test_predictions.csv", index=False)
df.to_csv(OUT / "wine_dataset.csv", index=False)
print("Saved dataset, predictions and charts in output/.")
