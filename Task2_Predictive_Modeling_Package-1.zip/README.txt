TASK 2 - PREDICTIVE MODELING USING MACHINE LEARNING

Files:
- Task2_Project_Report.pdf: report with methodology, evaluation and charts.
- Task2_Predictive_Modeling.ipynb: Jupyter notebook.
- task2_predictive_modeling.py: standalone script.
- wine_dataset.csv: dataset used.
- charts/: confusion matrix, feature importance, ROC curves.

Run:
1. Install: pip install pandas matplotlib scikit-learn
2. Run: python task2_predictive_modeling.py
3. Output files will be saved in output/.

Dataset note:
The Wine Recognition dataset is a standard educational dataset bundled with scikit-learn.
Check the internship portal for any required dataset, file format, or template before submitting.
Test accuracy for this fixed split: 1.0000 (100.00%).
