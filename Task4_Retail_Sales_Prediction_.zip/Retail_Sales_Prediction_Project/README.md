# Retail Sales Prediction & Business Insights System

**Task 4 – Data Science | Domain: Retail**

## Project overview
This project demonstrates retail data analysis and monthly sales forecasting.

## Dataset transparency
`Dataset.csv` contains **2,400 simulated transaction records** generated for this educational project. It is not an actual retailer's operational dataset. Values and trends are illustrative. Do not present them as verified market facts.

## Deliverables
- `Dataset.csv` — transaction-level data
- `retail_sales_analysis.py` — complete Python implementation
- `Retail_Sales_Analysis.ipynb` — practical notebook
- `graphs/` — generated visualizations
- `Project_Report.pdf` — documentation and findings

## Analysis included
1. Data inspection and quality checks
2. Sales by product category
3. Region-wise sales performance
4. Monthly sales trends
5. Random Forest monthly sales forecast
6. MAE, RMSE and R² evaluation

## Setup
```bash
pip install pandas numpy matplotlib scikit-learn jupyter
```

## Run
Keep the CSV, Python script and notebook in the same folder.

```bash
python retail_sales_analysis.py
```

Or open `Retail_Sales_Analysis.ipynb` in Jupyter Notebook.

## Machine-learning design
Monthly revenue is forecast using calendar variables and lagged monthly sales (1, 2, 3, 6 and 12 months). The model uses a chronological 80/20 train-test split.

## Important limitations
The dataset is synthetic, and the forecast is a demonstration only. Model scores do not prove real-world accuracy. For deployment, replace this data with authorized real retailer data and validate against suitable baselines.

## Suggested citation
Global Superstore-style field structure adapted for an educational retail analytics exercise; transaction values in this project are simulated and independently generated.
