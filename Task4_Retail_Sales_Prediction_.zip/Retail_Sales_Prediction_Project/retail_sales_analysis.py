"""
Retail Sales Prediction & Business Insights System
Dataset: illustrative synthetic Indian retail transactions.
Run: pip install pandas numpy matplotlib scikit-learn
     python retail_sales_analysis.py
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

ROOT = Path(__file__).resolve().parent
df = pd.read_csv(ROOT / "Dataset.csv", parse_dates=["Order_Date"])
print("Rows, columns:", df.shape)
print("\\nMissing values:\\n", df.isna().sum())
print("Duplicate rows:", df.duplicated().sum())

# Basic data validation and feature creation
df = df.drop_duplicates().dropna(subset=["Order_Date", "Sales", "Region", "Category"])
df["Month"] = df["Order_Date"].dt.to_period("M").dt.to_timestamp()

# Business insights
print("\\nTotal sales (INR):", round(df["Sales"].sum(), 2))
print("Total profit (INR):", round(df["Profit"].sum(), 2))
print("\\nSales by category:\\n", df.groupby("Category")["Sales"].sum().sort_values(ascending=False))
print("\\nSales by region:\\n", df.groupby("Region")["Sales"].sum().sort_values(ascending=False))

monthly = df.groupby("Month")["Sales"].sum().sort_index().asfreq("MS", fill_value=0)
(ROOT / "graphs").mkdir(exist_ok=True)

monthly.plot(figsize=(10, 5), title="Monthly Retail Sales Trend")
plt.ylabel("Sales (INR)"); plt.tight_layout()
plt.savefig(ROOT / "graphs/monthly_sales_trend.png", dpi=160); plt.close()

df.groupby("Category")["Sales"].sum().sort_values().plot(kind="barh", figsize=(8, 5),
    title="Sales by Product Category")
plt.xlabel("Sales (INR)"); plt.tight_layout()
plt.savefig(ROOT / "graphs/category_sales.png", dpi=160); plt.close()

df.groupby("Region")["Sales"].sum().sort_values().plot(kind="bar", figsize=(8, 5),
    title="Regional Sales Performance")
plt.ylabel("Sales (INR)"); plt.tight_layout()
plt.savefig(ROOT / "graphs/region_sales.png", dpi=160); plt.close()

# Forecast monthly sales using lag features and chronological validation.
features = pd.DataFrame({
    "month_num": monthly.index.month,
    "year": monthly.index.year,
    "trend": np.arange(len(monthly))
}, index=monthly.index)
for lag in [1, 2, 3, 6, 12]:
    features[f"lag_{lag}"] = monthly.shift(lag)
model_data = features.join(monthly.rename("target")).dropna()

split = int(len(model_data) * 0.80)
train, test = model_data.iloc[:split], model_data.iloc[split:]
X_train, y_train = train.drop(columns="target"), train["target"]
X_test, y_test = test.drop(columns="target"), test["target"]

model = RandomForestRegressor(n_estimators=300, random_state=42, max_depth=6,
                              min_samples_leaf=2)
model.fit(X_train, y_train)
pred = model.predict(X_test)
mae = mean_absolute_error(y_test, pred)
rmse = np.sqrt(mean_squared_error(y_test, pred))
r2 = r2_score(y_test, pred)
print(f"\\nTest MAE: INR {mae:,.2f}")
print(f"Test RMSE: INR {rmse:,.2f}")
print(f"Test R2: {r2:.3f}")

plt.figure(figsize=(9, 5))
plt.plot(y_test.index, y_test.values, marker="o", label="Actual")
plt.plot(y_test.index, pred, marker="o", label="Predicted")
plt.title("Monthly Sales: Actual vs Predicted (Test Set)")
plt.ylabel("Sales (INR)"); plt.legend(); plt.tight_layout()
plt.savefig(ROOT / "graphs/actual_vs_predicted.png", dpi=160); plt.close()

# Forecast one month beyond the dataset.
last = monthly.index[-1]
next_row = {
    "month_num": (last + pd.offsets.MonthBegin(1)).month,
    "year": (last + pd.offsets.MonthBegin(1)).year,
    "trend": len(monthly)
}
for lag in [1, 2, 3, 6, 12]:
    next_row[f"lag_{lag}"] = monthly.iloc[-lag]
next_month = last + pd.offsets.MonthBegin(1)
forecast = model.predict(pd.DataFrame([next_row]))[0]
print(f"Next-month forecast for {next_month:%B %Y}: INR {forecast:,.2f}")
