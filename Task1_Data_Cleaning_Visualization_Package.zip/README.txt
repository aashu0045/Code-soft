TASK 1 - DATA CLEANING & VISUALIZATION

Files:
- raw_retail_sales.csv: raw illustrative dataset with intentionally introduced data-quality issues.
- cleaned_retail_sales.csv: cleaned output dataset.
- Task1_Data_Cleaning_Visualization.ipynb: Jupyter Notebook walkthrough.
- task1_data_cleaning.py: standalone Python script.
- Task1_Project_Report.pdf: project report with charts.
- charts/: exported visualizations.

IMPORTANT:
The dataset is synthetic/illustrative. If the internship portal has a required dataset or exact submission template, use that instead of claiming this sample is portal-provided.

To run:
1. Keep raw_retail_sales.csv and task1_data_cleaning.py in the same folder.
2. Install packages: pip install pandas numpy matplotlib seaborn
3. Run: python task1_data_cleaning.py
4. Find outputs in the output/ folder.

Summary:
Rows before cleaning: 123
Missing cells before cleaning: 7
Duplicate rows before cleaning: 3
Rows after cleaning: 120
Missing cells after cleaning: 0
Duplicate rows after cleaning: 0
