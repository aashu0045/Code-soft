"""
Task 1: Data Cleaning & Visualization
Dataset: Illustrative retail sales dataset created for this project.
Run: pip install pandas numpy matplotlib seaborn
     python task1_data_cleaning.py
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

DATA = Path("raw_retail_sales.csv")
OUT = Path("output")
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA)
print("Initial shape:", df.shape)
print("\\nMissing values before cleaning:\\n", df.isna().sum())
print("\\nDuplicate rows before cleaning:", df.duplicated().sum())

# Standardize text columns
for col in ["Product", "Region"]:
    df[col] = df[col].astype("string").str.strip().str.title()

# Parse date and numeric columns
df["Order_Date"] = pd.to_datetime(df["Order_Date"], dayfirst=True, errors="coerce", format="mixed")
for col in ["Units_Sold", "Unit_Price", "Sales_Amount"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# Handle missing values
for col in ["Units_Sold", "Unit_Price"]:
    df[col] = df[col].fillna(df[col].median())
df["Units_Sold"] = df["Units_Sold"].round().clip(lower=1)
for col in ["Product", "Region"]:
    df[col] = df[col].fillna(df[col].mode(dropna=True).iloc[0])

# Recalculate dependent value for consistency
df["Sales_Amount"] = df["Units_Sold"] * df["Unit_Price"]

# Remove duplicate records
df = df.drop_duplicates().copy()

# Detect and cap outliers using IQR
def cap_outliers_iqr(series):
    q1, q3 = series.quantile([0.25, 0.75])
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    print(f"IQR limits for {series.name}: {lower:.2f} to {upper:.2f}")
    return series.clip(lower, upper)

df["Units_Sold"] = cap_outliers_iqr(df["Units_Sold"])
df["Sales_Amount"] = cap_outliers_iqr(df["Sales_Amount"])

# Handle invalid dates and create a month feature
df["Order_Date"] = df["Order_Date"].fillna(df["Order_Date"].mode().iloc[0])
df["Month"] = df["Order_Date"].dt.to_period("M").astype(str)

print("\\nMissing values after cleaning:\\n", df.isna().sum())
print("Duplicate rows after cleaning:", df.duplicated().sum())
print("Cleaned shape:", df.shape)

# Visualizations
sns.set_theme()
plt.figure(figsize=(8, 5))
sns.barplot(data=df, x="Product", y="Sales_Amount", estimator=sum, errorbar=None)
plt.title("Total Sales by Product")
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig(OUT / "sales_by_product.png")
plt.show()

plt.figure(figsize=(8, 5))
sns.barplot(data=df, x="Region", y="Sales_Amount", estimator=sum, errorbar=None)
plt.title("Total Sales by Region")
plt.tight_layout()
plt.savefig(OUT / "sales_by_region.png")
plt.show()

plt.figure(figsize=(8, 5))
sns.histplot(df["Sales_Amount"], bins=15, kde=True)
plt.title("Distribution of Sales Amount")
plt.tight_layout()
plt.savefig(OUT / "sales_distribution.png")
plt.show()

plt.figure(figsize=(8, 5))
sns.scatterplot(data=df, x="Units_Sold", y="Sales_Amount", hue="Product")
plt.title("Units Sold vs Sales Amount")
plt.tight_layout()
plt.savefig(OUT / "units_vs_sales.png")
plt.show()

df.to_csv(OUT / "cleaned_retail_sales.csv", index=False)
print("Saved cleaned dataset and charts in the output folder.")
